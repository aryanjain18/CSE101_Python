n = int(input("Enter n - "))

def uppatern(m,n):
    if n == 0:
        pass
    else:
        print("*"*n,end="")
        print(" "*(m-n),end="")
        print(" "*(m-n),end="")
        print("*"*n)
        return uppatern(m,n-1)

def downpatern(m,n):
    if n == m+1:
        pass
    elif n == 0:
        return downpatern(m,n+1)
    else:
        print("*"*n,end="")
        print(" "*(m-n),end="")
        print(" "*(m-n),end="")
        print("*"*n)
        return downpatern(m,n+1)
    
uppatern(n,n)
downpatern(n,0)
